package puc.android.calculadoraimc_somativa1;

import android.content.Context;
import android.media.AudioMetadata;
import android.nfc.FormatException;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView textDisplay;
    TextView textInfo;
    EditText weight;
    EditText height;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        textDisplay = findViewById(R.id.displayIMC);
        textInfo = findViewById(R.id.textInfor);
        weight = findViewById(R.id.editTextWeight);
        height = findViewById(R.id.editTextHeight);
    }

    protected float getNumFromEditText(float id) {
        String aux;
        if(id == 1) {
            aux = weight.getText().toString();
        } else {
            aux = height.getText().toString();
        }

        return Float.parseFloat(aux);
    }



    public void calculateButtonOnClick(View v){
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(
                Context.INPUT_METHOD_SERVICE
        );
        View currentFocus = getCurrentFocus();
        if (inputMethodManager != null && currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(
                    currentFocus.getWindowToken(), 0
            );
        }

        try {

            float input1 = getNumFromEditText(1);
            float input2 = getNumFromEditText(2);
            float result = input1 / (input2 * input2);
            textDisplay.setText(String.valueOf(result));

            if(weight == null && height == null) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_LONG).show();

            } else if (result < 18.5) {
                textInfo.setText("ABAIXO DO PESO:\n\nUm IMC abaixo de 18,5 indica baixo peso. \n\n" +
                        "Essencialmente, pode ser um alerta para desnutrição ou outras condições de saúde. " +
                        "Baixo peso requer avaliação médica, pois afeta o sistema imunológico, " +
                        "aumentando a suscetibilidade a infecções.");
            } else if (result >= 18.5 && result < 25.0) {
                textInfo.setText("PESO IDEAL:\n\nIMC entre 18,5 e 24,9 é considerado normal.\n\n" +
                        "\nEstar nesta faixa sugere um equilíbrio saudável entre peso e altura, " +
                        "diminuindo o risco de doenças. Manter-se nesta categoria " +
                        "envolve dieta equilibrada e atividade física.");
            } else if (result >= 25.0 && result < 30.0) {
                textInfo.setText("SOBREPESO:\n\n" +
                        "Valores de IMC entre 25 e 29,9 apontam sobrepeso.\n\n" +
                        "\nEmbora não classificado como obesidade, já manifesta um " +
                        "risco aumentado de doenças cardiovasculares e diabetes. " +
                        "Buscar orientação para redução de peso é prudente.");
            } else if (result > 29.9 && result < 35.0) {
                textInfo.setText("OBESIDADE GRAU 1:\n\n" +
                        "Valores de IMC entre 29,9 e apontam obesidade grau 1.\n\n" +
                        "Risco moderado de diabetes tipo 2 " +
                        "Obtenha apoio profissional para estratégias de perda de peso e controle de saúde.");
            } else if (result >= 35 && result < 39.9) {
                textInfo.setText("OBESIDADE GRAU 2:\n\n" +
                        "Valores de IMC entre 35 e 39,9 e apontam obesidade grau 2.\n\n" +
                        "Aumenta complicações cardíacas. " +
                        "Obtenha apoio profissional para estratégias de perda de peso e controle de saúde.");
            } else if (result >= 40.0) {
                textInfo.setText("OBESIDADE GRAU 3:\n\n" +
                        "Valores de IMC acima 40.00 apontam obesidade grau 3.\n\n" +
                        "Elevado risco de comorbidades graves. " +
                        "Obtenha apoio profissional para estratégias de perda de peso e controle de saúde.");
            }
        } catch (NumberFormatException e){
            Toast.makeText(this, "Por favor, verifique os campos obrigatórios.", Toast.LENGTH_LONG).show();
        }

    }
}
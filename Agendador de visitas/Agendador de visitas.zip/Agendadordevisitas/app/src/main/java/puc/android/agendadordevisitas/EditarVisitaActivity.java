package puc.android.agendadordevisitas;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Button;
import android.widget.Toast;
import android.os.Bundle;

public class EditarVisitaActivity extends AppCompatActivity {

    private EditText editNome, editTel, editLocal, editData, editHora;
    private Button salvarButton;
    private int visitaId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_visita);

        editNome = findViewById(R.id.editNome);
        editTel = findViewById(R.id.editTel);
        editLocal = findViewById(R.id.editLocal);
        editData = findViewById(R.id.editData);
        editHora = findViewById(R.id.editHora);
        salvarButton = findViewById(R.id.salvarEdicao);

        Intent intent = getIntent();
        visitaId = intent.getIntExtra("id", -1);
        String nome = intent.getStringExtra("nome");
        String tel = intent.getStringExtra("tel");
        String local = intent.getStringExtra("local");
        String data = intent.getStringExtra("data");
        String hora = intent.getStringExtra("hora");

        editNome.setText(nome);
        editTel.setText(tel);
        editLocal.setText(local);
        editData.setText(data);
        editHora.setText(hora);

        salvarButton.setOnClickListener( view -> {
            String novoNome = editNome.getText().toString();
            String novoTel = editTel.getText().toString();
            String novoLocal = editLocal.getText().toString();
            String novaData = editData.getText().toString();
            String novaHora = editHora.getText().toString();

            VisitaDBHelper dbHelper = new VisitaDBHelper(this);
            dbHelper.atualizarVisita(visitaId, novoNome, novoTel, novoLocal, novaData, novaHora);

            Toast.makeText(this, "Visita atualizada com sucesso!", Toast.LENGTH_SHORT).show();

            finish();
        });
    }
}

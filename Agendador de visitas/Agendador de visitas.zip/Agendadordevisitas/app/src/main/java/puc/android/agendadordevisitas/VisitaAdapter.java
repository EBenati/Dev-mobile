package puc.android.agendadordevisitas;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.TextView;
import android.view.ViewGroup;
import android.view.View;
import java.util.List;

public class VisitaAdapter extends RecyclerView.Adapter<VisitaAdapter.VisitaViewHolder> {
    private List<Visita> visitas;

    public VisitaAdapter(List<Visita> visitas) {
        this.visitas = visitas;
    }

    @NonNull
    @Override
    public VisitaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_visita, parent, false);
        return new VisitaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(VisitaViewHolder holder, int position) {
        Visita visita = visitas.get(position);
        holder.txtNome.setText("Nome: " + visita.getNome());
        holder.txtTel.setText("Telefone: " + visita.getTel());
        holder.txtLocal.setText("Endereço: " + visita.getLocal());
        holder.txtData.setText("Data: " + visita.getData());
        holder.txtHora.setText("Horário: " + visita.getHora());

        holder.apagarButton.setOnClickListener( view -> {
            Visita visitaApagar = visitas.get(position);
            VisitaDBHelper dbHelper = new VisitaDBHelper(view.getContext());
            dbHelper.apagarVisita(visitaApagar.getId());
            visitas.remove(position);
            notifyItemRemoved(position);
        });

        holder.editarButton.setOnClickListener(view -> {
            Context context = view.getContext();
            Intent intent = new Intent(context, EditarVisitaActivity.class);
            intent.putExtra("id", visita.getId());
            intent.putExtra("nome", visita.getNome());
            intent.putExtra("tel", visita.getTel());
            intent.putExtra("local", visita.getLocal());
            intent.putExtra("data", visita.getData());
            intent.putExtra("hora", visita.getHora());
            context.startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return visitas.size();
    }

    public static class VisitaViewHolder extends RecyclerView.ViewHolder {
        TextView txtNome, txtTel, txtLocal, txtData, txtHora;
        Button apagarButton, editarButton;

        public VisitaViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNome = itemView.findViewById(R.id.txtNome);
            txtTel = itemView.findViewById(R.id.txtTel);
            txtLocal = itemView.findViewById(R.id.txtLocal);
            txtData = itemView.findViewById(R.id.txtData);
            txtHora = itemView.findViewById(R.id.txtHora);
            apagarButton = itemView.findViewById(R.id.apagarButton);
            editarButton = itemView.findViewById(R.id.editarButton);
        }
    }
}


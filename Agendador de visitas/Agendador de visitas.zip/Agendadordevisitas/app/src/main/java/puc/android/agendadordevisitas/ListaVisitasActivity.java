package puc.android.agendadordevisitas;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.activity.EdgeToEdge;
import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

public class ListaVisitasActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    VisitaAdapter adapter;

    List<Visita> visitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_visitas);

        recyclerView = findViewById(R.id.recyclerViewVisitas);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        visitas = new ArrayList<>();
        adapter = new VisitaAdapter(visitas);
        recyclerView.setAdapter(adapter);
    }

    private void carregarVisitas() {
        VisitaDBHelper dbHelper = new VisitaDBHelper(this);
        List<Visita> listaAtualizada = dbHelper.buscarTodasVisitas();

        visitas.clear();
        visitas.addAll(listaAtualizada);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarVisitas();
    }

}


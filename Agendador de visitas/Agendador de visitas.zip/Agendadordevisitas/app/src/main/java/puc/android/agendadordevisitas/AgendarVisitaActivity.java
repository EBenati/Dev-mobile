package puc.android.agendadordevisitas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import java.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class AgendarVisitaActivity extends AppCompatActivity {
    EditText nome, local, tel;
    TextView data, hora;
    Button selecionarDataButton, selecionarHoraButton, salvarButton;
    String dataSelecionada = "", horaSelecionada = "";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendar_visita);

        nome = findViewById(R.id.nome);
        tel = findViewById(R.id.tel);
        local = findViewById(R.id.local);
        data = findViewById(R.id.data);
        hora = findViewById(R.id.hora);
        selecionarDataButton = findViewById(R.id.selecionarDataButton);
        selecionarHoraButton = findViewById(R.id.selecionarHoraButton);
        salvarButton = findViewById(R.id.salvarButton);

        selecionarDataButton.setOnClickListener(v -> {
            Calendar calendario = Calendar.getInstance();
            int ano = calendario.get(Calendar.YEAR);
            int mes = calendario.get(Calendar.MONTH);
            int dia = calendario.get(Calendar.DAY_OF_MONTH);

            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                dataSelecionada = dayOfMonth + "/" + (month + 1) + "/" + year;
                data.setText("Data: " + dataSelecionada);
            }, ano, mes, dia).show();
        });

        selecionarHoraButton.setOnClickListener(v -> {
            Calendar calendario = Calendar.getInstance();
            int hora_ = calendario.get(Calendar.HOUR_OF_DAY);
            int minuto = calendario.get(Calendar.MINUTE);

            new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                horaSelecionada = String.format("%02d:%02d", hourOfDay, minute);
                hora.setText("Hora: " + horaSelecionada);
            }, hora_, minuto, true).show();
        });

        salvarButton.setOnClickListener(view -> {
            String nomeVisita = nome.getText().toString();
            String telVisita = tel.getText().toString();
            String localVisita = local.getText().toString();

            if (nomeVisita.isEmpty() || telVisita.isEmpty() || localVisita.isEmpty() || dataSelecionada.isEmpty() || horaSelecionada.isEmpty()) {
                Toast.makeText(this, "Por favor, preencher todos os campos!", Toast.LENGTH_LONG).show();
            } else {
                Visita visita = new Visita(nomeVisita, telVisita, localVisita, dataSelecionada, horaSelecionada);
                VisitaDBHelper db = new VisitaDBHelper(this );
                db.inserirVisita(visita);
                finish();
            }
        });
    }
    
}

package puc.android.agendadordevisitas;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;

public class VisitaDBHelper extends SQLiteOpenHelper {
    private static final String NOME_BANCO = "visitas.db";
    private static final int VERSAO = 1;
    private static final String TABELA = "visitas";

    public VisitaDBHelper(Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABELA + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT, " +
                "tel TEXT, " +
                "local TEXT, " +
                "data TEXT, " +
                "hora TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA);
        onCreate(db);
    }

    public List<Visita> buscarTodasVisitas() {
        List<Visita> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM visitas", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
                String tel = cursor.getString(cursor.getColumnIndexOrThrow("tel"));
                String local = cursor.getString(cursor.getColumnIndexOrThrow("local"));
                String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
                String hora = cursor.getString(cursor.getColumnIndexOrThrow("hora"));

                Visita visita = new Visita(id, nome, tel, local, data, hora);
                lista.add(visita);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lista;
    }


    public void inserirVisita(Visita visita) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nome", visita.getNome());
        valores.put("tel", visita.getTel());
        valores.put("local", visita.getLocal());
        valores.put("data", visita.getData());
        valores.put("hora", visita.getHora());
        db.insert(TABELA, null, valores);
        db.close();
    }

    public List<Visita> listarVisitas() {
        List<Visita> visitas = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABELA + " ORDER BY data, hora", null);

        while (cursor.moveToNext()) {
            String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
            String tel = cursor.getString(cursor.getColumnIndexOrThrow("tel"));
            String local = cursor.getString(cursor.getColumnIndexOrThrow("local"));
            String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
            String hora = cursor.getString(cursor.getColumnIndexOrThrow("hora"));
            visitas.add(new Visita(nome, tel, local, data, hora));
        }

        cursor.close();
        db.close();
        return visitas;
    }

    public void atualizarVisita(int id, String nome, String tel, String local, String data, String hora) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", nome);
        values.put("tel", tel);
        values.put("local", local);
        values.put("data", data);
        values.put("hora", hora);
        db.update("visitas", values, "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }


    public void apagarVisita(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("visitas", "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }



}


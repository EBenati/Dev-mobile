package puc.android.agendadordevisitas;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button agendarButton, mostrarVisitasButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        agendarButton = findViewById(R.id.agendarButton);
        mostrarVisitasButton = findViewById(R.id.mostrarVisitasButton);

            agendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AgendarVisitaActivity.class);
                startActivity(intent);
            }
        });

        mostrarVisitasButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListaVisitasActivity.class);
                startActivity(intent);
            }
        });
    }
}
